
#####1.0.6
* [添加] java.lang.Integer(int)扩展方法upto(), downto()
* [添加] java.lang.Long(long)扩展方法upto(), downto()
* [添加] GravatarTags直接生成<img>标签

#####1.0.5
* [更新] DateTimeMethods.setXxx更名为resetXxx
* [更新] StringMethods添加md5()/sha1()
* [添加] java.lang.Throwable扩展方法

#####1.0.4
* [更新] StringMethods添加aglinAt()方法
* [添加] java.util.Date扩展方法

#####1.0.3
* [添加] java.lang.String扩展方法

#####1.0.2
* [添加] 通用function方便的从gravatar.com获取用户头像

#####1.0.1
* [添加] SpringSecurity框架提供的Velocity-TAG移植
* [添加] 通用随机字符串/随机UUID生成函数

#####1.0.0
* [添加] 针对SpringMVC框架的国际化/本地化开发的TAG
* [添加] 针对SpringMVC框架的通用函数
* [添加] 针对SpringMVC框架的数据绑定和验证开发的通用函数
* [添加] ApacheShiro框架JSP-TAG移植
