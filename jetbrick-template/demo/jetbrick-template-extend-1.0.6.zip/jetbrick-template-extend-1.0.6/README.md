请看在线文档
https://github.com/yingzhuo/jetbrick-template-extend/wiki