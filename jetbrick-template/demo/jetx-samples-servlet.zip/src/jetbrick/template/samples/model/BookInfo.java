package jetbrick.template.samples.model;

import java.util.Date;

public class BookInfo {
    protected Integer id; // ID
    protected String name; // 书名(name)
    protected Integer authorId; // 作者ID(author_id)
    protected Double price; // 价格(price)
    protected Date publicationDate; // 发布时间(publication_date)

    public BookInfo() {
    }

    public BookInfo(Integer id, String name, Integer authorId, Double price, Date publicationDate) {
        this.id = id;
        this.name = name;
        this.authorId = authorId;
        this.price = price;
        this.publicationDate = publicationDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAuthorId() {
        return authorId;
    }

    public void setAuthorId(Integer authorId) {
        this.authorId = authorId;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Date getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(Date publicationDate) {
        this.publicationDate = publicationDate;
    }
}
