package jetbrick.template.samples.extension;

import jetbrick.template.JetAnnoations;

@JetAnnoations.Functions
public class Functions {

    public static String hello() {
        return "hello";
    }
}
