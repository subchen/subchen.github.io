package cn.nutz.bean;

import org.nutz.dao.entity.annotation.*;

/**
* 
*/
@Table("game")
public class Game {

	/**
	 * ID
	 */
	@Id
	@Column("id")
	private Integer id;
	/**
	 * 游戏名称
	 */
	@Column("gameName")
	private String gameName;
	/**
	 * 下载次数
	 */
	@Column("downloads")
	private Integer downloads;
	/**
	 * 文件大小
	 */
	@Column("size")
	private Long size;
	/**
	 * 资费
	 */
	@Column("tariff")
	private String tariff;
	/**
	 * 语言
	 */
	@Column("language")
	private String language;
	/**
	 * 版本
	 */
	@Column("version")
	private String version;
	/**
	 * 更新时间
	 */
	@Column("update")
	private java.util.Date update;
	/**
	 * 固件版本
	 */
	@Column("firmware")
	private String firmware;
	/**
	 * 开发者
	 */
	@Column("developers")
	private String developers;
	/**
	 * 下载地址
	 */
	@Column("download")
	private String download;
	/**
	 * 应用介绍
	 */
	@Column("introduction")
	private String introduction;
	/**
	 * 短信发送地址
	 */
	@Column("url")
	private String url;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public Integer getDownloads() {
		return downloads;
	}
	public void setDownloads(Integer downloads) {
		this.downloads = downloads;
	}
	public Long getSize() {
		return size;
	}
	public void setSize(Long size) {
		this.size = size;
	}
	public String getTariff() {
		return tariff;
	}
	public void setTariff(String tariff) {
		this.tariff = tariff;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public java.util.Date getUpdate() {
		return update;
	}
	public void setUpdate(java.util.Date update) {
		this.update = update;
	}
	public String getFirmware() {
		return firmware;
	}
	public void setFirmware(String firmware) {
		this.firmware = firmware;
	}
	public String getDevelopers() {
		return developers;
	}
	public void setDevelopers(String developers) {
		this.developers = developers;
	}
	public String getDownload() {
		return download;
	}
	public void setDownload(String download) {
		this.download = download;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
}