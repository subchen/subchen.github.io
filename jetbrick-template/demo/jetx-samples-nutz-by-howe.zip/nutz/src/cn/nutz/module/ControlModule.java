package cn.nutz.module;

import javax.servlet.http.HttpServletRequest;

import jetbrick.template.web.JetWebEngineLoader;

import org.nutz.dao.Dao;
import org.nutz.ioc.loader.annotation.IocBean;
import org.nutz.mvc.annotation.At;
import org.nutz.mvc.annotation.Ok;
import org.nutz.mvc.annotation.Param;

import cn.nutz.bean.Game;

//@IocBean(fields = {"dao"})
public class ControlModule {

    private Dao dao;

    @At("/list")
    @Ok(".jetx:/WEB-INF/html/list.jetx")
    public Game list(@Param("name") String name, HttpServletRequest request) {
        Game game = new Game();
        game.setGameName("剑灵");
        return game;
    }
}
