�ؼ��ļ�
1
/weixin/src/com/liebao/MainModule.java
2
/weixin/src/com/liebao/module/ControlModule.java
3
/weixin/WebContent/WEB-INF/html/list.jetx