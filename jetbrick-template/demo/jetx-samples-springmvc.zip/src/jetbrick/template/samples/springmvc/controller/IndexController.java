package jetbrick.template.samples.springmvc.controller;

import jetbrick.template.samples.dao.DaoUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class IndexController {

    @RequestMapping("/index")
    public String index() {
        return "index";
    }

    @RequestMapping("/users")
    public String users(ModelMap modelMap) {
        modelMap.put("userlist", DaoUtils.getUserList());
        return "users";
    }

    @RequestMapping("/books")
    public String books(@RequestParam("author") int authorId, ModelMap modelMap) {
        modelMap.put("author", DaoUtils.getUser(authorId));
        return "books";
    }
}
