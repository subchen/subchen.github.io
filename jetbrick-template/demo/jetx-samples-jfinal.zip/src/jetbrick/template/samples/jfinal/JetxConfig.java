package jetbrick.template.samples.jfinal;

import jetbrick.template.samples.jfinal.controller.*;
import jetbrick.template.web.jfinal.JetTemplateRenderFactory;
import com.jfinal.config.*;

public class JetxConfig extends JFinalConfig {

    @Override
    public void configConstant(Constants me) {
        me.setMainRenderFactory(new JetTemplateRenderFactory());
        me.setDevMode(true);
    }

    @Override
    public void configRoute(Routes me) {
        me.add("/index", IndexController.class);
        me.add("/users", UsersController.class);
        me.add("/books", BooksController.class);
    }

    @Override
    public void configPlugin(Plugins me) {
    }

    @Override
    public void configInterceptor(Interceptors me) {
    }

    @Override
    public void configHandler(Handlers me) {
    }
}
