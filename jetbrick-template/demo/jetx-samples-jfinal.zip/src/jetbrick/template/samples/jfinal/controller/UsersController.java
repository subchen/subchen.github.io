package jetbrick.template.samples.jfinal.controller;

import jetbrick.template.samples.dao.DaoUtils;
import com.jfinal.core.Controller;

public class UsersController extends Controller {

    public void index() {
        setAttr("userlist", DaoUtils.getUserList());
        render("/users.jetx");
    }

}
