package jetbrick.template.samples.jfinal.controller;

import jetbrick.template.samples.dao.DaoUtils;
import com.jfinal.core.Controller;

public class BooksController extends Controller {

    public void index() {
        int author = getParaToInt("author");
        setAttr("author", DaoUtils.getUser(author));
        render("/books.jetx");
    }
}
