package jetbrick.template.samples.extension;

import java.util.ArrayList;
import java.util.List;
import jetbrick.template.JetAnnoations;
import jetbrick.template.samples.dao.DaoUtils;
import jetbrick.template.samples.model.BookInfo;
import jetbrick.template.samples.model.UserInfo;

@JetAnnoations.Methods
public class Methods {

    public static List<BookInfo> getBooks(UserInfo user) {
        List<BookInfo> books = new ArrayList<BookInfo>();
        for (BookInfo book : DaoUtils.getBookList()) {
            if (book.getAuthorId().equals(user.getId())) {
                books.add(book);
            }
        }
        return books;
    }

    public static UserInfo getAuthorUser(BookInfo book) {
        return DaoUtils.getUser(book.getAuthorId());
    }
}
