package samples.jetx.springmvc.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import samples.jetx.springmvc.domain.Contact;

import com.google.common.collect.Lists;

@Controller
public class IndexController {

	private static final Logger LOGGER = LoggerFactory.getLogger(IndexController.class);
	
	private static final List<Contact> ALL_CONTACTS = Lists.newArrayList(
				new Contact("10001", "无名氏", "11111"),
				new Contact("10002", "无名氏", "11111"),
				new Contact("10003", "无名氏", "11111"),
				new Contact("10004", "无名氏", "11111"),
				new Contact("10005", "无名氏", "11111"),
				new Contact("10006", "无名氏", "11111"),
				new Contact("10007", "无名氏", "11111"),
				new Contact("10008", "无名氏", "11111"),
				new Contact("10009", "无名氏", "11111"),
				new Contact("10010", "无名氏", "11111"),
				new Contact("10011", "无名氏", "11111"),
				new Contact("10012", "无名氏", "11111"),
				new Contact("10013", "无名氏", "11111"),
				new Contact("10014", "无名氏", "11111"),
				new Contact("10015", "无名氏", "11111"),
				new Contact("10016", "无名氏", "11111"),
				new Contact("10017", "无名氏", "11111")
			);

	@RequestMapping("/index")
	public String index(ModelMap modelMap) {
		LOGGER.debug("导入数据: {}", ALL_CONTACTS);
		modelMap.put("contacts", ALL_CONTACTS);
		return "index";
	}

	@RequestMapping("/index2")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView("index");

		LOGGER.debug("导入数据: {}", ALL_CONTACTS);
		modelAndView.addObject("contacts", ALL_CONTACTS);
		return modelAndView;
	}
}
