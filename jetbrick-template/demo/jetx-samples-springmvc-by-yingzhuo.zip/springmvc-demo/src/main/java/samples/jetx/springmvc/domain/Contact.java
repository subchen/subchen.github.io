package samples.jetx.springmvc.domain;

import java.io.Serializable;

import com.google.common.base.Objects;

public class Contact implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String name;
	private String qq;
	private String desc = "这个人很懒，更本就没有写描述啊～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～";
	
	// ----------------------------------------------------------------------
	
	public Contact() {
		super();
	}

	public Contact(String id, String name, String qq) {
		super();
		this.id = id;
		this.name = name;
		this.qq = qq;
	}

	// ----------------------------------------------------------------------
	
	@Override
	public String toString() {
		return Objects.toStringHelper(this)
				.add("id", this.getId())
				.add("name", this.getName())
				.toString();
	}
	
	// ----------------------------------------------------------------------

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
}
