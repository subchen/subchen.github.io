package jetbrick.template.samples.jodd.action;

import java.util.Collection;
import jetbrick.template.samples.dao.DaoUtils;
import jetbrick.template.samples.model.UserInfo;
import jodd.madvoc.meta.*;

@MadvocAction
public class UsersAction {

    @Out
    Collection<UserInfo> userlist;

    @Action(extension = Action.NONE)
    public Object view() {
        userlist = DaoUtils.getUserList();
        return "jetx:/users.jetx";
    }
}
