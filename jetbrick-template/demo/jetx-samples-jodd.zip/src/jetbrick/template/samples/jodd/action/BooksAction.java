package jetbrick.template.samples.jodd.action;

import jetbrick.template.samples.dao.DaoUtils;
import jetbrick.template.samples.model.UserInfo;
import jodd.madvoc.meta.*;

@MadvocAction
public class BooksAction {

    @In
    Integer author;

    @Out
    UserInfo authorUser;

    @Action(extension = Action.NONE)
    public Object view() {
        authorUser = DaoUtils.getUser(author);
        return "jetx:/books.jetx";
    }
}
