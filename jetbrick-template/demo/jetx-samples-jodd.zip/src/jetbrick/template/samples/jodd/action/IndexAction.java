package jetbrick.template.samples.jodd.action;

import jodd.madvoc.meta.Action;
import jodd.madvoc.meta.MadvocAction;

@MadvocAction
public class IndexAction {

    @Action(extension = Action.NONE)
    public Object view() {
        return "redirect:/index.html";
    }
}
