package jetbrick.template.web.jodd;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jetbrick.template.*;
import jetbrick.template.web.JetWebContext;
import jetbrick.template.web.JetWebEngineLoader;
import jodd.madvoc.ActionRequest;
import jodd.madvoc.ScopeType;
import jodd.madvoc.component.MadvocController;
import jodd.madvoc.meta.In;
import jodd.madvoc.result.ActionResult;

public class JetTemplateResult extends ActionResult {
    @In(scope = ScopeType.CONTEXT)
    protected MadvocController madvocController;
    protected String contentType;

    public JetTemplateResult() {
        super("jetx");
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public ServletContext getServletContext() {
        return madvocController.getApplicationContext();
    }

    @Override
    public void render(ActionRequest actionRequest, Object resultObject, String resultValue, String resultPath) throws Exception {
        final HttpServletRequest request = actionRequest.getHttpServletRequest();
        final HttpServletResponse response = actionRequest.getHttpServletResponse();

        if (JetWebEngineLoader.unavailable()) {
            JetWebEngineLoader.setServletContext(request.getSession().getServletContext());
        }
        JetEngine engine = JetWebEngineLoader.getJetEngine();
        
        response.setCharacterEncoding(engine.getConfig().getOutputEncoding());
        if (contentType != null) {
            response.setContentType(contentType);
        }

        JetContext context = new JetWebContext(request, response);
        JetTemplate template = engine.getTemplate(resultPath);
        template.render(context, response.getOutputStream());
    }
}